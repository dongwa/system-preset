#!/bin/sh

# LaunchXTerm.sh
# X11_xterm
#
# Created by James Tuley on 2/18/07.
# Copyright 2007 Jay Tuley. All rights reserved.

/usr/X11R6/bin/xterm